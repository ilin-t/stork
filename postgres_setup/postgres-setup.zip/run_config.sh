bash ../../postgres_setup/build_postgres_config.sh
bash ../../postgres_setup/start_task_postgres_config.sh
