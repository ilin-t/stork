docker stop postgres-test-db-config
docker rm postgres-test-db-config

